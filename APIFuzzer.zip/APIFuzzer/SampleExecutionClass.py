import SeleniumCases
import unittest


unittest.main(module=SeleniumCases)